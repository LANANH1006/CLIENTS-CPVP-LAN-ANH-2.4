package com.safeanchor;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;

import java.util.ArrayList;
import java.util.List;

/** HUD thông tin: FPS, ping, RAM, tọa độ, keystrokes. */
public class Hud2 {
    public static void render(DrawContext ctx, RenderTickCounter tc) {
        MinecraftClient mc = MinecraftClient.getInstance(); Config c = Config.I;
        if (!c.enabled || mc.player == null || mc.world == null || mc.options.hudHidden) return;
        int H = ctx.getScaledWindowHeight();
        List<String> lines = new ArrayList<>();
        if (c.hudFps) lines.add("FPS: " + mc.getCurrentFps() + " / " + mc.options.getMaxFps().getValue());
        if (c.hudPing) {
            var e = mc.getNetworkHandler() == null ? null : mc.getNetworkHandler().getPlayerListEntry(mc.player.getUuid());
            lines.add("Ping: " + (e == null ? "?" : e.getLatency()) + " ms");
        }
        if (c.hudRam) {
            Runtime rt = Runtime.getRuntime();
            lines.add("RAM: " + (rt.totalMemory() - rt.freeMemory()) / 1048576 + " / " + rt.maxMemory() / 1048576 + " MB");
        }
        if (c.hudCoords) lines.add(String.format("XYZ: %d %d %d", mc.player.getBlockX(), mc.player.getBlockY(), mc.player.getBlockZ()));
        int y = 26;
        for (String s : lines) {
            int w = mc.textRenderer.getWidth(s);
            ctx.fill(2, y - 2, w + 8, y + 10, 0x90000000);
            ctx.drawText(mc.textRenderer, s, 5, y, 0xFF000000 | (c.chroma ? Util.chroma(y * 0.01) : c.hudColor), true);
            y += 13;
        }
        if (c.hudKeys) {
            int bx = 8, by = H - 62;
            key(ctx, mc, "W", bx + 20, by, 18, mc.options.forwardKey.isPressed());
            key(ctx, mc, "A", bx, by + 20, 18, mc.options.leftKey.isPressed());
            key(ctx, mc, "S", bx + 20, by + 20, 18, mc.options.backKey.isPressed());
            key(ctx, mc, "D", bx + 40, by + 20, 18, mc.options.rightKey.isPressed());
            key(ctx, mc, "SPACE", bx, by + 40, 58, mc.options.jumpKey.isPressed());
        }
    }

    static void key(DrawContext ctx, MinecraftClient mc, String s, int x, int y, int w, boolean on) {
        int h = s.length() > 1 ? 14 : 18;
        ctx.fill(x, y, x + w, y + h, on ? 0xB0FF69B4 : 0x90000000);
        ctx.drawCenteredTextWithShadow(mc.textRenderer, s, x + w / 2, y + (h - 8) / 2, on ? 0xFF000000 : 0xFFFFFFFF);
    }
}
