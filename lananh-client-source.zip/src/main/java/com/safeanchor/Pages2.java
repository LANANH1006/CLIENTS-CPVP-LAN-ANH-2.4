package com.safeanchor;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ClickableWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Supplier;

/** Các trang cài đặt cho tính năng mới (v2.3). */
public class Pages2 {
    static Config C() { return Config.I; }
    static MinecraftClient mc() { return MinecraftClient.getInstance(); }

    static Screen pvp(Screen p) {
        List<Supplier<ClickableWidget>> m = new ArrayList<>();
        m.add(Pages.toggle("Auto PvP (phím V)", () -> C().autoPvp, v -> { if (v != C().autoPvp) AutoPvp.toggle(mc()); }));
        m.add(Pages.toggle("Tự bật Auto Crystal/Anchor khi PvP", () -> C().pvpCrystal, v -> C().pvpCrystal = v));
        m.add(Pages.toggle("Tự chạy tới đối thủ", () -> C().pvpWalk, v -> C().pvpWalk = v));
        m.add(Pages.toggle("Tự đổi totem", () -> C().autoTotem, v -> C().autoTotem = v));
        m.add(Pages.slider("Tầm đánh", 2.5, 6, false, () -> C().pvpRange, v -> C().pvpRange = v));
        m.add(Pages.slider("Độ mượt xoay (thấp = mượt)", 10, 100, true, () -> C().pvpSmooth * 100, v -> C().pvpSmooth = v / 100.0));
        m.add(Pages.toggle("Auto Crystal", () -> C().crystal, v -> C().crystal = v));
        m.add(Pages.toggle("Safe Anchor", () -> C().anchor, v -> C().anchor = v));
        return new MenuScreen("Auto PvP", p, m);
    }

    static Screen mine(Screen p) {
        List<Supplier<ClickableWidget>> m = new ArrayList<>();
        m.add(Pages.toggle("Tự đào (phím N)", () -> C().mineOn, v -> { if (v != C().mineOn) AutoMine.toggle(mc()); }));
        m.add(Pages.slider("Tầm tìm block (block)", 6, 24, true, () -> C().mineRange, v -> C().mineRange = v));
        TextFieldWidget[] tf = new TextFieldWidget[1];
        m.add(() -> { tf[0] = new TextFieldWidget(mc().textRenderer, 0, 0, 220, 20, Text.literal("id")); tf[0].setPlaceholder(Text.literal("vd: iron_ore")); tf[0].setMaxLength(64); return tf[0]; });
        m.add(Pages.button("➕ Thêm block cần đào", () -> {
            String s = tf[0].getText().trim().toLowerCase();
            if (!s.isEmpty() && !C().mineList.contains(s)) { C().mineList.add(s); Config.save(); }
            mc().setScreen(mine(p));
        }));
        for (String id : new ArrayList<>(C().mineList))
            m.add(Pages.button("❌ Bỏ: " + id, () -> { C().mineList.remove(id); Config.save(); mc().setScreen(mine(p)); }));
        return new MenuScreen("Tự đào", p, m);
    }

    static Screen ah(Screen p) {
        List<Supplier<ClickableWidget>> m = new ArrayList<>();
        m.add(Pages.toggle("Auto /ah mua", () -> C().ahOn, v -> C().ahOn = v));
        TextFieldWidget[] kw = new TextFieldWidget[1], pr = new TextFieldWidget[1];
        m.add(() -> { kw[0] = new TextFieldWidget(mc().textRenderer, 0, 0, 220, 20, Text.literal("kw")); kw[0].setPlaceholder(Text.literal("Tên món (vd: diamond)")); kw[0].setText(C().ahKeyword); return kw[0]; });
        m.add(() -> { pr[0] = new TextFieldWidget(mc().textRenderer, 0, 0, 220, 20, Text.literal("pr")); pr[0].setPlaceholder(Text.literal("Giá tối đa (0 = không giới hạn)")); pr[0].setText(C().ahMaxPrice == 0 ? "" : String.valueOf((long) C().ahMaxPrice)); return pr[0]; });
        m.add(Pages.button("💾 Lưu từ khóa + giá", () -> {
            C().ahKeyword = kw[0].getText().trim();
            try { C().ahMaxPrice = pr[0].getText().isBlank() ? 0 : Double.parseDouble(pr[0].getText().trim()); } catch (Exception e) { C().ahMaxPrice = 0; }
            Config.save(); Util.msg("Đã lưu /ah");
        }));
        m.add(Pages.slider("Chu kỳ mở /ah (tick)", 20, 400, true, () -> C().ahInterval, v -> C().ahInterval = (int) v));
        return new MenuScreen("Auto /ah", p, m);
    }

    static Screen sus(Screen p) {
        List<Supplier<ClickableWidget>> m = new ArrayList<>();
        m.add(Pages.toggle("Hiện chunk đáng nghi (đỏ)", () -> C().susOn, v -> C().susOn = v));
        m.add(Pages.slider("Số block người đặt tối thiểu / chunk", 10, 300, true, () -> C().susMin, v -> C().susMin = (int) v));
        m.add(Pages.slider("Sâu dưới mặt đất (block)", 1, 20, true, () -> C().susDepth, v -> C().susDepth = (int) v));
        m.add(Pages.slider("Độ đậm khối đặc (ESP)", 10, 200, true, () -> C().espAlpha, v -> C().espAlpha = (int) v));
        return new MenuScreen("Sus chunk", p, m);
    }

    static Screen chat(Screen p) {
        List<Supplier<ClickableWidget>> m = new ArrayList<>();
        m.add(Pages.toggle("Dịch chat Anh -> Việt (hiện thêm dòng)", () -> C().chatIn, v -> C().chatIn = v));
        m.add(Pages.toggle("Tin gõ tiếng Việt (có dấu) -> gửi tiếng Anh", () -> C().chatOut, v -> C().chatOut = v));
        return new MenuScreen("Dịch chat", p, m);
    }

    static Screen shock(Screen p) {
        List<Supplier<ClickableWidget>> m = new ArrayList<>();
        m.add(Pages.toggle("Shockwave (sóng xung kích)", () -> C().shockOn, v -> C().shockOn = v));
        m.add(Pages.toggle("Khi nhảy lên", () -> C().shockJump, v -> C().shockJump = v));
        m.add(Pages.toggle("Khi tiếp đất", () -> C().shockLand, v -> C().shockLand = v));
        m.add(Pages.toggle("Dùng khối (block) thay vì hạt màu", () -> C().shockBlock, v -> C().shockBlock = v));
        m.add(Pages.color("hạt (khi không dùng khối)", () -> C().shockColor, v -> C().shockColor = v));
        m.add(Pages.slider("Bán kính", 1, 12, false, () -> C().shockRadius, v -> C().shockRadius = v));
        m.add(Pages.slider("Độ cao nâng lên", 0.2, 4, false, () -> C().shockHeight, v -> C().shockHeight = v));
        m.add(Pages.slider("Thời gian (tick)", 4, 60, true, () -> C().shockTicks, v -> C().shockTicks = (int) v));
        m.add(Pages.slider("Rơi tối thiểu để nổ (block)", 0, 10, false, () -> C().shockMinFall, v -> C().shockMinFall = v));
        return new MenuScreen("Shockwave", p, m);
    }

    static Screen trail(Screen p) {
        List<Supplier<ClickableWidget>> m = new ArrayList<>();
        m.add(Pages.toggle("Trail (vệt đuôi)", () -> C().trailOn, v -> C().trailOn = v));
        m.add(Pages.toggle("Cầu vồng (chroma)", () -> C().trailChroma, v -> C().trailChroma = v));
        m.add(Pages.color("đầu vệt (đậm)", () -> C().trailColor1, v -> C().trailColor1 = v));
        m.add(Pages.color("cuối vệt (nhạt)", () -> C().trailColor2, v -> C().trailColor2 = v));
        m.add(Pages.slider("Độ dài (tick)", 8, 120, true, () -> C().trailLen, v -> C().trailLen = (int) v));
        m.add(Pages.slider("Độ đậm ở đầu", 20, 255, true, () -> C().trailAlpha, v -> C().trailAlpha = (int) v));
        m.add(Pages.slider("Chiều cao vệt", 0.1, 2, false, () -> C().trailHeight, v -> C().trailHeight = v));
        return new MenuScreen("Trail", p, m);
    }

    static Screen visual(Screen p) {
        List<Supplier<ClickableWidget>> m = new ArrayList<>();
        m.add(Pages.toggle("Chroma toàn client (ESP, chữ, hạt)", () -> C().chroma, v -> C().chroma = v));
        m.add(Pages.toggle("Đổi giờ trong game (bầu trời sáng/tối)", () -> C().skyOn, v -> C().skyOn = v));
        m.add(Pages.slider("Giờ (0 sáng, 6000 trưa, 13000 tối, 18000 đêm)", 0, 24000, true, () -> C().skyTime, v -> C().skyTime = (int) v));
        return new MenuScreen("Hiển thị", p, m);
    }

    static Screen hud(Screen p) {
        List<Supplier<ClickableWidget>> m = new ArrayList<>();
        m.add(Pages.toggle("FPS (hiện cả FPS tối đa)", () -> C().hudFps, v -> C().hudFps = v));
        m.add(Pages.toggle("Ping", () -> C().hudPing, v -> C().hudPing = v));
        m.add(Pages.toggle("RAM", () -> C().hudRam, v -> C().hudRam = v));
        m.add(Pages.toggle("Tọa độ", () -> C().hudCoords, v -> C().hudCoords = v));
        m.add(Pages.toggle("Keystrokes (WASD + Space)", () -> C().hudKeys, v -> C().hudKeys = v));
        m.add(Pages.color("chữ HUD", () -> C().hudColor, v -> C().hudColor = v));
        return new MenuScreen("HUD thông tin", p, m);
    }

    static Screen combo(Screen p) {
        List<Supplier<ClickableWidget>> m = new ArrayList<>();
        m.add(Pages.button("▶ Chạy combo ngay (nhìn vào block)", () -> { mc().setScreen(null); AnchorCombo.start(mc()); }));
        m.add(Pages.toggle("Đặt obsidian chắn trước mình", () -> C().comboObs, v -> C().comboObs = v));
        m.add(Pages.slider("Độ trễ giữa các bước (tick)", 0, 10, true, () -> C().comboDelay, v -> C().comboDelay = (int) v));
        return new MenuScreen("Combo Anchor 1 phím (J)", p, m);
    }

    static Screen vel(Screen p) {
        List<Supplier<ClickableWidget>> m = new ArrayList<>();
        m.add(Pages.toggle("Velocity (giảm knockback)", () -> C().velOn, v -> C().velOn = v));
        m.add(Pages.slider("Giữ lại % đẩy ngang", 0, 100, true, () -> C().velH, v -> C().velH = (int) v));
        m.add(Pages.slider("Giữ lại % đẩy dọc", 0, 100, true, () -> C().velV, v -> C().velV = (int) v));
        return new MenuScreen("Velocity", p, m);
    }
}
