package com.safeanchor;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import net.minecraft.util.math.Vec3d;

/** Đang ở trên không (bị hất bay lên): lập tức lao xuống đối thủ và đập mace liên tục. */
public class MaceSpam {
    static boolean held;

    static void release(MinecraftClient mc) {
        if (held) { mc.options.forwardKey.setPressed(false); held = false; }
    }

    public static void tick(MinecraftClient mc) {
        Config c = Config.I; var p = mc.player;
        if (!c.maceSpam || !c.enabled || p == null || mc.world == null || mc.interactionManager == null || c.autoMace) { release(mc); return; }
        if (mc.currentScreen != null || p.isGliding()) { release(mc); return; }
        PlayerEntity t = Util.nearestEnemy(12);
        if (t == null || !Util.has(s -> s.isOf(Items.MACE))) { release(mc); return; }
        if (p.isOnGround()) { release(mc); return; }
        Util.selectItem(s -> s.isOf(Items.MACE));
        Util.aim(p, t.getPos().add(0, t.getHeight() * 0.5, 0));
        double horiz = Math.hypot(p.getX() - t.getX(), p.getZ() - t.getZ());
        mc.options.forwardKey.setPressed(horiz > 1.0); held = true;
        // lao xuống nhanh
        if (c.maceSpamFast && p.getY() > t.getY() + 1.0) {
            Vec3d v = p.getVelocity();
            if (v.y > -2.2) p.setVelocity(v.x, v.y - 0.35, v.z);
        }
        double dist = Util.distToBox(p.getEyePos(), t.getBoundingBox());
        if (dist <= c.maceHitDist && p.getAttackCooldownProgress(0.5f) >= 0.9f) {
            mc.interactionManager.attackEntity(p, t); p.swingHand(Hand.MAIN_HAND);
            AutoCrystal.hitTarget = t; AutoCrystal.hitTicks = 60;
        }
    }
}
